@(Bandeja de Entrada)[Practica]
###Practica 1 - Enrutamiento Dinamico 
*3 de Junion de 2019* 
Integrantes: 
**Roberto Valdez Barba**
**Descripcion:**
La siguiente practica tiene como objetivo observar el comportamiento del enrutamiento dinámico en un topologia construida en GNS3.



Parte 1: Armar la red y configurar los dispositivos. Realizar enrutamiento dinámico en dicha topología
##### Topologia
![Alt text](./Practica 1 Configuracion .png)

#### Tabla de direccionamiento
| Dispositivo | Interfaz | Dirección IP | Máscara de Subred | Puerta de enlace predeterminada | 
|:--:||:-:|:-:|:-:|:-:|
|Router **Saber**|ETH0/0|10.10.10.5|255.255.255.252| -- |
||ETH1/0|10.10.10.1|255.255.255.252| -- |
||ETH2/0|192.168.1.254|255.255.255.0|--|
|Router **Archer**|ETH0/0|10.10.10.25|255.255.255.252|--|
||ETH1/0|192.168.2.254|255.255.255.0|--|
||ETH2/0|10.10.10.22|255.255.255.252|--|
|Router **Ruler**|ETH0/0|10.10.10.42|255.255.255.252|--|
||ETH1/0|10.10.10.45|255.255.255.252|--|
||ETH2/0|192.168.3.254|255.255.255.0|--|
|Router **Lancer**|ETH0/0|10.10.10.37|255.255.255.252|--|
||ETH1/0|10.10.10.10|255.255.255.252|--|
||ETH2/0|10.10.10.30|255.255.255.252|--|
|Router **Caster**|ETH0/0|10.10.10.17|255.255.255.252|--|
||ETH1/0|10.10.10.14|255.255.255.252|--|
||ETH2/0|10.10.10.33|255.255.255.252|--|
|Router **PE4**|ETH0/0|10.10.10.2|255.255.255.252|--|
||ETH1/0|10.10.10.9|255.255.255.252|--|
|Router **PE4-Cas**|ETH0/0|10.10.10.13|255.255.255.252|--|
||ETH1/0|10.10.10.6|255.255.255.252|--|
|Router **PE2**|ETH0/0|10.10.10.26|255.255.255.252|--|
||ETH1/0|10.10.10.29|255.255.255.252|--|
|Router **PE2-Cas**|ETH0/0|10.10.10.21|255.255.255.252|--|
||ETH1/0|10.10.10.18|255.255.255.252|--|
|Router **PE3**|ETH0/0|10.10.10.46|255.255.255.252|--|
||ETH1/0|10.10.10.38|255.255.255.252|--|
|Router **PE3-Cas**|ETH0/0|10.10.10.42|255.255.255.252|--|
||ETH1/0|10.10.10.41|255.255.255.252|--|
|**PC-Saber**|ETH0/0|192.168.1.1|255.255.255.0|192.168.1.254|
|**PC-Archer**|ETH0/0|192.4168.2.1|255.255.255.0|192.168.2.254|
|**PC-Ruler**|ETH0/0|192.4168.3.1|255.255.255.0|192.168.3.254|


#### Parte 1: Enrutamiento Dinámico 
#### Probar el protocolo de enrutamiento 
##### Configuracion del protocolo de enrutamiento 
A continuacion describiremos los comandos necesarios para configurar el enrutamiento en nuestro router 

    R1(config)#router rip
    R1(config)#version 2
    R1(config-router)#network 172.16.1.0 // Se refiere a  la red que deseamos configurar en nuestro router.
#### 1.1 Trace: Probar el protocolo de enrutamiento
(Para usar el comando Trace, use siempre los parámetros “-m 20 y -P 1”)
##### PC- Archer
**Trace de PC-Archer a PC-Saber:**
Comando utilizado:

    VPCS> trace 192.168.1.1 -m 20 -P 1
Respuesta la VPC:

![Alt text](./1559505851538.png)


**Trace de PC-Archer a PC-Ruler:**
Comando utilizado:

    VPCS> trace 192.168.3.1 -m 20 -P 1
Respuesta la VPC:
![Alt text](./1559506434792.png)



#### PC- Saber
**Trace de PC-Saber a PC-Archer:**
Comando utilizado:

    VPCS> trace 192.168.2.1 -m 20 -P 1

Respuesta la VPC:
![Alt text](./1559506532626.png)


**Trace de PC-Saber a PC-Ruler:**
Comando utilizado:

    VPCS> trace 192.168.3.1 -m 20 -P 1

Respuesta la VPC:
![Alt text](./1559506620099.png)


#### PC- Ruler
**Trace de PC-Ruler a PC-Archer:**
Comando utilizado:

    VPCS> trace 192.168.2.1 -m 20 -P 1  

![Alt text](./1559506677014.png)

**Trace de PC-Ruler a PC-Saber:**
Comando utilizado:

    VPCS> trace 192.168.1.1 -m 20 -P 1 


![Alt text](./1559506729107.png)

#### 2.1 Sobre la Topo logia original dibuja la designación de rutas de paquetes
En la siguiente imagen podemos seguir visualmente cuales son las rutas que eligen tomar los paquetes. 
**De Pc-Archer a PC-Saber**
![Alt text](./1559507609344.png)


**De Pc-Archer a PC-Ruler**
![Alt text](./1559507721570.png)

#### Parte 3: Tareas Administrativas
Procederemos a desconectar el camino de PE4-Cas como lo indica la practica para saber como esto afecta el comportamiento de la ruta. 
![Alt text](./1559508460289.png)

**Trace de PC-Ruler a PC-Saber:**
![Alt text](./1559508434116.png)
![Alt text](./1559508629804.png)

**De Pc-Archer a PC-Saber**
![Alt text](./1559508574262.png)
![Alt text](./1559508679668.png)


####Explicación:
Como podemos observar el las imágenes anteriores al no contar con el camino que utilizaba este busca rutas alternativas para poder llegar a la dirección destino. 

Realizaremos la misma prueba pero esta vez suspenderemos la conexión de PE3
![Alt text](./1559509757180.png)
**Trace de PC-Ruler a PC-Saber:**
![Alt text](./1559509874964.png)
![Alt text](./1559510017198.png)


**De Pc-Archer a PC-Saber**
![Alt text](./1559509925001.png)
![Alt text](./1559508679668.png)

Como en el experimento anterior vemos como el algoritmo de enrutamiento busca una ruta alternativa, se puede apreciar por la el trace de cada uno así como el reflejo en el trafico capturado. 

![Alt text](./1559515973333.png)

Practica por Roberto Valdez Barba 
ESCOM - Administracion de Servicios en Red.
